
package com.ytc.app8.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ytc.app8.dao.PurchaseDao;
import com.ytc.app8.model.Purchase;
import com.ytc.app8.service.PurchaseService;


@Service
public class PurchaseServiceImpl implements PurchaseService {
	
	@Autowired
	private PurchaseDao purchaseDao;

	@Override
	public Page<Purchase> findPaginated(Pageable pageable) {
		List<Purchase> purchases = new ArrayList<Purchase>();
		purchases.add(purchaseDao.selectByPrimaryKey(1L));
		int pageSize= pageable.getPageSize();
		int currentPage = pageable.getPageNumber();
		int startItem = currentPage * pageSize;
		List<Purchase> list;

		if (purchases.size() < startItem) {
			list = Collections.emptyList();
		} else {
			int toIndex = Math.min(startItem + pageSize, purchases.size());
			list = purchases.subList(startItem, toIndex);
		}
		Page<Purchase> purchasePage = new PageImpl<Purchase>(list, PageRequest.of(currentPage,pageSize),purchases.size());
		
		return purchasePage;
	}

	@Override
	public void add(Purchase purchase) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Purchase> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Purchase> findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Purchase Purchase) {
		// TODO Auto-generated method stub
		
	}
}

package com.ytc.app8.dto;

import java.util.Objects;

public class PurchaseDto {
    private String left;
    private String right;

    public PurchaseDto() {
    }

    public PurchaseDto(String left, String right) {
        this.left = left;
        this.right = right;
    }

    public String getLeft() {
        return this.left;
    }

    public void setLeft(String left) {
        this.left = left;
    }

    public String getRight() {
        return this.right;
    }

    public void setRight(String right) {
        this.right = right;
    }

    public PurchaseDto left(String left) {
        setLeft(left);
        return this;
    }

    public PurchaseDto right(String right) {
        setRight(right);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof PurchaseDto)) {
            return false;
        }
        PurchaseDto purchaseDto = (PurchaseDto) o;
        return Objects.equals(left, purchaseDto.left) && Objects.equals(right, purchaseDto.right);
    }

    @Override
    public int hashCode() {
        return Objects.hash(left, right);
    }

    @Override
    public String toString() {
        return "{" +
            " left='" + getLeft() + "'" +
            ", right='" + getRight() + "'" +
            "}";
    }

}

package com.ytc.app8.controller;

import java.util.Optional;

import com.ytc.app8.model.Purchase;
import com.ytc.app8.service.PurchaseService;

// import com.ytc.chinesenewyear.app8.dto.Purchase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/purchase")
public class PurchaseController {

    @Autowired
    private PurchaseService purchaseService;

    @GetMapping("/toFindAll")
    public String toFindAll() {
        return "query";
    }

    @RequestMapping("/findAll")
    public String findAll(Model model, @RequestParam("page") Optional<Integer> page, @RequestParam("size") Optional<Integer> size) {
        int currentPage = page.orElse(1);
        int pageSize = size.orElse(20);

        Page<Purchase> purchasePage = purchaseService.findPaginated(PageRequest.of(currentPage - 1, pageSize));

        model.addAttribute("purchasePage", purchasePage);

        model.addAttribute("previousPage", Math.max(currentPage-1,1));
        model.addAttribute("oobl", currentPage < 0);
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("nextPage", Math.min(currentPage+1,purchasePage.getTotalPages()));
        model.addAttribute("oobr", currentPage > purchasePage.getTotalPages());
        return "app8/PurchaseList";
    }

    @RequestMapping("/toAdd")
    public String toAdd(Model model) {
        return "add";
    }

    @RequestMapping("/add")
    public String add(Purchase purchase) {
        purchaseService.add(purchase);
        return "redirect:/purchase/toFindAll";
    }

    @RequestMapping(value = "toUpdate")
    public String toUpdate(Model model, Long id) {
        model.addAttribute("purchase", purchaseService.findById(id));
        return "update";
    }
    @RequestMapping(value = "update")
    public String update(@RequestParam Purchase purchase) {
        purchaseService.update(purchase);
        return "redirect:/purchase/toFindAll";
    }
    // @RequestMapping(value = "delete")
    // public String delete(@RequestParam Purchase purchase) {
    //     purchaseService.delete(purchase);
    //     return "redirect:/purchase/toFindAll";
    // }
}

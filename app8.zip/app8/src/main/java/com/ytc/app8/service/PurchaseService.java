package com.ytc.app8.service;


import com.ytc.app8.model.Purchase;
import com.ytc.app8.model.*;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;


public interface PurchaseService {

	void add(Purchase purchase);

	List<Purchase> findAll();

	Optional<Purchase> findById(Long id);

	Page<Purchase> findPaginated(Pageable pageable);

	void update(Purchase Purchase);

}
